//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : TERM.C
// FILE VERSION : 1.0
// PROGRAMMER   : Fateh Ali Shahrukh Khan
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
//  1.0, 2025-10-24, Fateh Ali Shahrukh Khan
//   - Initial release
//----------------------------------------------------------------------------
// INCLUSION LOCK
//----------------------------------------------------------------------------

#ifndef TERM_H_
#define TERM_H_

//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------

#include "global.h"
#include "uart.h"
#include <time.h>

//----------------------------------------------------------------------------
// FUNCTION PROTOTYPES
//----------------------------------------------------------------------------

void TERM_Init( time_t t );

void TERM_SetPos( uint8_t x, uint8_t y );

void TERM_SaveCursor( void );
void TERM_RestoreCursor( void );
void LED_TEXT(void);
void TERM_ShowCursor( void );
void TERM_HideCursor( void );
void UPTIME(void);
void CLK_COUNT(void);
void CLK_FORMAT(uint32_t clk);
void SWITCH_COUNT(void);
void SYSTEM_RESTART_TEXT(void);
void message(void);
void CMSG_ATEMP (void);
void CMSG_CCST (void);
void CMSG_EL507 (void);
void CMSG_HEADER (void);
void CMSG_VOLTAGE (void);

void Clear_17_14_to_1_30(void);

void CMSG_ITEMP (void);
void AMBI_DIS_UART(uint16_t aValues[3]);
void CLEAR_AMBI_DIS_UART(void);
void ITemp_Dis_UART(uint16_t aValues[3]);
void Voltage_UART_DIS(uint16_t aValues[3]);
void DISP_MSGS(uint16_t msg);
void TIME_AND_DISPLAY(void);
void CLOCK(void);
void HELP(void);
enum MSGS {

    e_CMSG_ATEMP = 1,
    e_CMSG_CCST,
    e_CMSG_EL507,
    e_CMSG_HEADER,
    e_CMSG_ITEMP,
    e_CMSG_TIME,
    e_CMSG_VOLTAGE,



};


void RPM_STATIC();
void RPM_DYNAMIC(float RPM);

//----------------------------------------------------------------------------
// CONSTANTS
//----------------------------------------------------------------------------

#endif // TERM_H_

//----------------------------------------------------------------------------
// END TERM.H
//----------------------------------------------------------------------------
