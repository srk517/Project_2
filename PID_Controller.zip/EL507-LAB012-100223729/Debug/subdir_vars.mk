################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../tm4c123gh6pm.cmd 

ASM_SRCS += \
../el507.asm \
../lcda.asm \
../upper.asm 

C_SRCS += \
../Inits.c \
../adc.c \
../contact.c \
../date.c \
../global.c \
../i2c.c \
../lcd.c \
../led.c \
../main.c \
../max.c \
../mcp7940m.c \
../motor.c \
../pcf8574a.c \
../probe.c \
../qei.c \
../queue.c \
../quotes.c \
../sysclk.c \
../systick.c \
../term.c \
../tm4c123gh6pm_startup_ccs.c \
../uart.c 

C_DEPS += \
./Inits.d \
./adc.d \
./contact.d \
./date.d \
./global.d \
./i2c.d \
./lcd.d \
./led.d \
./main.d \
./max.d \
./mcp7940m.d \
./motor.d \
./pcf8574a.d \
./probe.d \
./qei.d \
./queue.d \
./quotes.d \
./sysclk.d \
./systick.d \
./term.d \
./tm4c123gh6pm_startup_ccs.d \
./uart.d 

OBJS += \
./Inits.obj \
./adc.obj \
./contact.obj \
./date.obj \
./el507.obj \
./global.obj \
./i2c.obj \
./lcd.obj \
./lcda.obj \
./led.obj \
./main.obj \
./max.obj \
./mcp7940m.obj \
./motor.obj \
./pcf8574a.obj \
./probe.obj \
./qei.obj \
./queue.obj \
./quotes.obj \
./sysclk.obj \
./systick.obj \
./term.obj \
./tm4c123gh6pm_startup_ccs.obj \
./uart.obj \
./upper.obj 

ASM_DEPS += \
./el507.d \
./lcda.d \
./upper.d 

OBJS__QUOTED += \
"Inits.obj" \
"adc.obj" \
"contact.obj" \
"date.obj" \
"el507.obj" \
"global.obj" \
"i2c.obj" \
"lcd.obj" \
"lcda.obj" \
"led.obj" \
"main.obj" \
"max.obj" \
"mcp7940m.obj" \
"motor.obj" \
"pcf8574a.obj" \
"probe.obj" \
"qei.obj" \
"queue.obj" \
"quotes.obj" \
"sysclk.obj" \
"systick.obj" \
"term.obj" \
"tm4c123gh6pm_startup_ccs.obj" \
"uart.obj" \
"upper.obj" 

C_DEPS__QUOTED += \
"Inits.d" \
"adc.d" \
"contact.d" \
"date.d" \
"global.d" \
"i2c.d" \
"lcd.d" \
"led.d" \
"main.d" \
"max.d" \
"mcp7940m.d" \
"motor.d" \
"pcf8574a.d" \
"probe.d" \
"qei.d" \
"queue.d" \
"quotes.d" \
"sysclk.d" \
"systick.d" \
"term.d" \
"tm4c123gh6pm_startup_ccs.d" \
"uart.d" 

ASM_DEPS__QUOTED += \
"el507.d" \
"lcda.d" \
"upper.d" 

C_SRCS__QUOTED += \
"../Inits.c" \
"../adc.c" \
"../contact.c" \
"../date.c" \
"../global.c" \
"../i2c.c" \
"../lcd.c" \
"../led.c" \
"../main.c" \
"../max.c" \
"../mcp7940m.c" \
"../motor.c" \
"../pcf8574a.c" \
"../probe.c" \
"../qei.c" \
"../queue.c" \
"../quotes.c" \
"../sysclk.c" \
"../systick.c" \
"../term.c" \
"../tm4c123gh6pm_startup_ccs.c" \
"../uart.c" 

ASM_SRCS__QUOTED += \
"../el507.asm" \
"../lcda.asm" \
"../upper.asm" 


