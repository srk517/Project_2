//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : TERM.C
// FILE VERSION : 1.0
// PROGRAMMER   : Fateh Ali Shahrukh Khan
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
//  1.0, 2025-10-24, Fateh Ali Shahrukh Khan
//   - Initial release
//
//----------------------------------------------------------------------------
// MODULE DESCRIPTION
//----------------------------------------------------------------------------
//
// Code to support a VT100 compatible terminal.
//
//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------

#include "term.h"
#include "stdio.h"
#include "date.h"
#include "mcp7940m.h"
#include <time.h>
#include "adc.h"
#include "global.h"
#include "motor.h"
#include "max.h"
//----------------------------------------------------------------------------
// EXTERNAL REFERENCES
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// FUNCTION : TERM_Init( void )
// PURPOSE  : Initializes the terminal interface
//----------------------------------------------------------------------------
float  fExtTemp;
float  fIntTemp;
//float fAIN4;
//float VREFP = 3.311f;
//float VREFN = 0.0f;



void TERM_Init( time_t t )
{
    // Clear the screen and display information
    UART_SendMessage( "\e[2J\e[2H" ); // Clear screen and home cursor
    UART_SendMessage( "\e(B" );  // ASCII Set
    UART_SendMessage( "\e[0m" ); // Normal Attributes

    //show_date();
    show (t);

    //UART_SendMessage( "EL 507 Embedded Control Systems II\r\n" );
    //UART_SendMessage("\x1b[92m" "Fateh Ali Shahrukh Khan's EL 507 Embedded Control Systems II" "\x1b[0m\r\n");
   // UART_SendMessage( "Lab 6 Terminal Interfacing.\r\n\n" );

    UART_SendMessage("----------------------------------------\r\n");
    UART_SendMessage("System     : Speed Control\r\n");
    UART_SendMessage("Company    : Confederation College\r\n");
    UART_SendMessage("Platform   : TM4C123GH6PM\r\n");
    UART_SendMessage("Date       : 2025-12-10\r\n");
    UART_SendMessage("Programmer : ""\x1b[92m" "Fateh Ali Shahrukh Khan" "\x1b[0m\r\n");
    UART_SendMessage("----------------------------------------\r\n");

    /*----------------------------------------
    Firmware : EL 507 � LAB 12
    System : Speed Control
    Company : Confederation College
    Platform : TM4C123GH6PM
    Date : [Date of demonstration in ISO 8601 format]
    Programmer : [Student Name]
    ----------------------------------------*/



}

void SYSTEM_RESTART_TEXT(void){

    UART_SendMessage("\nSYSTEM RESTART :\r\n");


}

void HELP(void){

    TERM_SetPos(17,18);
    UART_SendMessage("\x1B[0K");
    TERM_SetPos(1,19);
    UART_SendMessage("Available Commands                                                                                            ");
    UART_SendMessage("\r\n");
    UART_SendMessage("C     - Display the date and time");
    UART_SendMessage("\r\n");
   UART_SendMessage(
            "T     - Display the ambient and internal temperature");
    UART_SendMessage("\r\n");
    UART_SendMessage(
            "R     - Display the speed of the output shaft in RPM");
    UART_SendMessage("\r\n");
    UART_SendMessage(
            "0-9,F - Sets the speed of the output shaft");
    UART_SendMessage("\r\n");
    UART_SendMessage(
            "A     - Change the mode of control to automatic");
    UART_SendMessage("\r\n");
    UART_SendMessage(
            "M     - Change the mode of control to manual");
    UART_SendMessage("\r\n");
    UART_SendMessage("I     - Display system infomation");
    UART_SendMessage("\r\n");
    UART_SendMessage("L     - Toggles the state of LED3");
    UART_SendMessage("\r\n");
    UART_SendMessage("\r\n");
    UART_SendMessage("<Ctrl>+R - Reset the embedded system");
    UART_SendMessage("\r\n");
    TERM_RestoreCursor();

}



void Clear_17_14_to_1_30(void)
{
    // Row 17: clear from col 14 to end of line
    int r;
    TERM_SetPos(17, 19);
    UART_SendMessage("\x1B[0K");

    // Rows 16 down to 2: clear entire lines
    for (r = 19; r < 31; r++) {
        TERM_SetPos(1, r);
        UART_SendMessage("\x1B[2K");
    }
    TERM_RestoreCursor();
    // Row 1: clear from start of line up to col 30
    //TERM_SetPos(1, 30);
    //UART_SendMessage("\x1B[1K");
}



void message(void){


    TERM_SetPos(1,18);
    UART_SendMessage("MESSAGE :\r\n");
    TERM_RestoreCursor();


}

void CMSG_ATEMP ( void){


   // TERM_SetPos(17,19);
    UART_SendMessage("Ambient Temperature: DD.D \xC2\xB0 C                                ");

//    fExtTemp = ((aValues[ 1 ]/4096.0f)*(VREFP-VREFN)/6.60f) * 100;
//    sprintf( sBuffer, "%4.1f", fExtTemp );
//
//    TERM_SetPos(38,8);
//    UART_SendMessage( sBuffer );

    //TERM_RestoreCursor();

}


void CMSG_TIME (void){

    TERM_SetPos(17,14);
    UART_SendMessage("Time                                                                  ");


}

void AMBI_DIS_UART(uint16_t aValues[3]){

    char sBuffer[10];
    fExtTemp = ((aValues[ 1 ]/4096.0f)*(VREFP-VREFN)/GAIN) * 100;
    fExtTemp = fExtTemp - SubQ + TEMP_OFFSET;
    sprintf( sBuffer, "%4.1f", fExtTemp );

   // TERM_SetPos(38,14);
    UART_SendMessage( sBuffer );
    //TERM_RestoreCursor();
    MAX_Write_AD1(MAX_ADDR,0x01,aValues,TEMP_OFFSET,SubQ);


}


void ITemp_Dis_UART(uint16_t aValues[3]){

    //char sBuffer[10];

    fIntTemp = (147.5f - ( 75.0f * ( VREFP - VREFN ) * ( aValues[2] / 4096.0f ))) ;
          fIntTemp = fIntTemp + ITempOFF+6;
          sprintf(g_smallBuffer, "%4.1f", fIntTemp );
          //TERM_SetPos(38,14);
          UART_SendMessage( g_smallBuffer );
          //TERM_RestoreCursor();


}


void Voltage_UART_DIS(uint16_t aValues[3]){


    //char sBuffer[10];
    fAIN4 = aValues[0];

    fAIN4 = ( fAIN4 / 4096.0f ) * ( VREFP - VREFN );
    fAIN4 = fAIN4 - SubQ;

   // Auto_Mode(fAIN4);

    sprintf( g_smallBuffer, "%5.3f", fAIN4 );
    TERM_SetPos(31,14);
    UART_SendMessage( g_smallBuffer );
    TERM_RestoreCursor();


}


void TIME_AND_DISPLAY(void){

   // TERM_SetPos(17,14);
    MCP7940M_Read( 0, g_aRTCData, 8 );
//    sprintf( g_sBuffer, "Time: %02X:%02X:%02X             ", g_aRTCData[ 2 ] & 0x1f, g_aRTCData[ 1 ] & 0x7f, g_aRTCData[ 0 ] & 0x7f );
//    UART_SendMessage( g_sBuffer);
    sprintf( g_sBuffer, "DATE: 20%02X-%02X-%02X     \r\n", g_aRTCData[ 6 ], g_aRTCData[ 5 ] & 0x1f, g_aRTCData[ 4 ] & 0x3f );
    UART_SendMessage( g_sBuffer);
    sprintf( g_sBuffer, "Time: %02X:%02X:%02X                                   ", g_aRTCData[ 2 ] & 0x1f, g_aRTCData[ 1 ] & 0x7f, g_aRTCData[ 0 ] & 0x7f );
    UART_SendMessage( g_sBuffer);
    TERM_RestoreCursor();

}


void CLOCK(void){


    MCP7940M_Read( 0, g_aRTCData, 8 );
    //    sprintf( g_sBuffer, "Time: %02X:%02X:%02X             ", g_aRTCData[ 2 ] & 0x1f, g_aRTCData[ 1 ] & 0x7f, g_aRTCData[ 0 ] & 0x7f );
    //    UART_SendMessage( g_sBuffer);
        sprintf( g_sBuffer, "20%02X-%02X-%02X     ", g_aRTCData[ 6 ], g_aRTCData[ 5 ] & 0x1f, g_aRTCData[ 4 ] & 0x3f );
        UART_SendMessage( g_sBuffer);
        sprintf( g_sBuffer, "%02X:%02X:%02X                                   ", g_aRTCData[ 2 ] & 0x1f, g_aRTCData[ 1 ] & 0x7f, g_aRTCData[ 0 ] & 0x7f );
        UART_SendMessage( g_sBuffer);
        TERM_RestoreCursor();


}


void RPM_STATIC(){

       TERM_SetPos(17,19);
       UART_SendMessage("Speed: #####.# RPM                                                              ");
       TERM_RestoreCursor();


}

void RPM_DYNAMIC(float RPM){

    //TERM_SetPos(25,14);

    sprintf( g_smallBuffer, "%6.2f", RPM );
     TERM_SetPos(24,19);
     UART_SendMessage( g_smallBuffer );
     TERM_RestoreCursor();
}


void DISP_MSGS(uint16_t msg){

    switch(msg){

    case  e_CMSG_ATEMP:

        CMSG_ATEMP();

        break;
    case  e_CMSG_CCST:

        CMSG_CCST();
        break;


    case e_CMSG_EL507:
        CMSG_EL507();
        break;
    case e_CMSG_HEADER:
        CMSG_HEADER();
        break;

    case e_CMSG_ITEMP:
        CMSG_ITEMP();
            break;

    case e_CMSG_VOLTAGE:
        CMSG_VOLTAGE();
            break;

    case e_CMSG_TIME:
        CMSG_TIME ();
        break;
   // case


    }



}


void CLEAR_AMBI_DIS_UART(void){

    TERM_SetPos(38,14);
       UART_SendMessage( "\x1B[2K");
       TERM_RestoreCursor();

}


void CMSG_CCST (void){
    TERM_SetPos(17,14);
    UART_SendMessage(" Confederation College School of Engineering Technology");
    TERM_RestoreCursor();

}

void CMSG_EL507 (void){
    TERM_SetPos(17,14);
    UART_SendMessage("EL507 Embedded Control Systems II                            ");
    TERM_RestoreCursor();

}

void CMSG_HEADER (void){
    TERM_SetPos(17,14);
    UART_SendMessage("Lab 10: External Peripherals                                     ");
    TERM_RestoreCursor();

}

void CMSG_ITEMP (void){
    //TERM_SetPos(17,18);
    UART_SendMessage("Internal Temperature: DDD  \xC2\xB0 C                            ");
    //TERM_RestoreCursor();

}

void CMSG_VOLTAGE (void){
    TERM_SetPos(17,14);
    UART_SendMessage(" PD3 Voltage: D.DDD V                                  ");
    TERM_RestoreCursor();

}






void LED_TEXT(void)
{

    UART_SendMessage("\n\tLED 1 :\r\n"); //UART_SendMessage("\e(0f\e(B"); //\tLED 1 :\x1B(0`\x1B(B\r\n //\e(0 `
    UART_SendMessage("\tLED 2 :\r\n");
    UART_SendMessage("\tLED 3 :\r\n");

}




void UPTIME(void){

    UART_SendMessage("\r\n\n");
    UART_SendMessage("UP-Time:\r\n");

}

void SWITCH_COUNT(void){
    //TERM_SetPos( 9 , 1 );
    UART_SendMessage("\r\n");
    UART_SendMessage("Count:\r\n");

}


void CLK_COUNT(){

    CLK_COUNT_ ++;


}

void CLK_FORMAT(uint32_t clk){

    //bool display = 0;
    uint32_t t_sec = clk / 1000;
    uint32_t min = t_sec / 60;
    uint32_t sec = t_sec % 60;
    if(!--SECOND_TIMER ){

        //display = 1;

       // char sBuffer[10];
        //TERM_SetPos(9,9);
        UART_SendMessage("\e[?25l");
        sprintf(g_smallBuffer, "%02u:%02u", min, sec);  // Format as MM:SS
        TERM_SetPos(10,21);
        UART_SendMessage("  ");
        TERM_SetPos(10,21);
        UART_SendMessage(g_smallBuffer);
        TERM_RestoreCursor();
        //display = 0;
        SECOND_TIMER = 1000;
    }
}
//----------------------------------------------------------------------------
// FUNCTION : TERM_SetPos( uint8_t x, uint8_t y )
// PURPOSE  : Moves the cursor to the specified x and y position
//----------------------------------------------------------------------------

void TERM_SetPos( uint8_t x, uint8_t y )
{
    //char sBuffer[ 16 ];
    sprintf( g_sBuffer, "\e[%u;%uH", y, x );
   // sprintf(sBuffer, "\033[%u;%uH", row, col);
    UART_SendMessage( g_sBuffer );
}

//----------------------------------------------------------------------------
// FUNCTION : TERM_SaveCursor( void )
// PURPOSE  : Save cursor and attributes
//----------------------------------------------------------------------------

void TERM_SaveCursor( void )
{
    UART_SendMessage( "\e7" );
}

//----------------------------------------------------------------------------
// FUNCTION : TERM_RestoreCursor( void )
// PURPOSE  : Restore cursor and attributes
//----------------------------------------------------------------------------

void TERM_RestoreCursor( void )
{
    UART_SendMessage( "\e8" );
}

void TERM_ShowCursor( void )
{
    UART_SendMessage( "\e[?25h" );
}
void TERM_HideCursor( void )
{
    UART_SendMessage( "\e[?25l" );
}


//----------------------------------------------------------------------------
// END TERM.C
//----------------------------------------------------------------------------
