//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : MAX.H
// FILE VERSION : 1.0
// PROGRAMMER   :  Fateh Ali Shahrukh Khan
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
// 1.0, 2025-11-25,  Fateh Ali Shahrukh Khan
//   - Initial release
//
//----------------------------------------------------------------------------
// MODULE DESCRIPTION
//----------------------------------------------------------------------------
//
// DAC
//
//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------
#ifndef MAX_H_
#define MAX_H_

#include "global.h"

#define MAX_ADDR 0x2C

void MAX518BCPA_Init(void);
void MAX518BCPA_Write(uint8_t uiSA, uint8_t uiData);
void MAX_Write_AD1(uint8_t uiSA,uint8_t ControlByte,uint16_t uiData[3],float t,float SubQ);




#endif
