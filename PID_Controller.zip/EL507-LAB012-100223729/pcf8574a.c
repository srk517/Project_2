//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : pcf8574.C
// FILE VERSION : 1.0
// PROGRAMMER   :  Fateh Ali Shahrukh Khan
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
// 1.0, 2025-11-25,  Fateh Ali Shahrukh Khan
//   - Initial release
//
//----------------------------------------------------------------------------
// MODULE DESCRIPTION
//----------------------------------------------------------------------------
//
// Remote 8-Bit I/O Expander
//
//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------

//#define SHORT_PRESS_STEP_RPM     100
//#define HOLD_RATE_RPM_PER_S      1000
//#define TICK_MS                  1
//#define HOLD_RATE_RPM_PER_TICK   ((HOLD_RATE_RPM_PER_S * TICK_MS) / 1000)

#include "pcf8574a.h"
#include "i2c.h"
#include "global.h"
#include "motor.h"
//----------------------------------------------------------------------------
// GLOBAL VARIABLES
//----------------------------------------------------------------------------

extern MOTOR_CONTROL_PARAMS g_MCP;
bool flag;
bool flag6;
//static uint8_t sw4_was_pressed = 0;

//----------------------------------------------------------------------------
// FUNCTION : PCF8574A_Init( void )
// PURPOSE  : Initializes the I/O expander
//----------------------------------------------------------------------------

void PCF8574A_Init( void )
{
    uint8_t uiData;

    // Configure LEDs and switches
    uiData = 0xE7;
    PCF8574A_Write( PCF8574A_SA, uiData );

    return;
}

//----------------------------------------------------------------------------
// FUNCTION : PCF8574A_Write( uint8_t uiSA, uint8_t uiData )
// PURPOSE  : Writes data to the I/O expander
//----------------------------------------------------------------------------

void PCF8574A_Write( uint8_t uiSA, uint8_t uiData )
{
    uint8_t uiMCS;

    // Write slave address and R/W = 0
    HWREG( I2C0_BASE + I2C_O_MSA ) = ( uiSA << 1 );

    // Write data to transmit register
    HWREG( I2C0_BASE + I2C_O_MDR ) = uiData;

    // Initiate I2C transaction
    uiMCS = I2C_MCS_RUN | I2C_MCS_START | I2C_MCS_STOP;
    HWREG( I2C0_BASE + I2C_O_MCS ) = uiMCS;

    // Wait until the controller is no longer busy
    I2C_WaitForControllerReady();

    return;
}

//----------------------------------------------------------------------------
// FUNCTION : PCF8574A_Read( uint8_t uiSA, uint8_t* puiData )
// PURPOSE  : Reads data from the I/O expander
//----------------------------------------------------------------------------

void PCF8574A_Read( uint8_t uiSA, uint8_t* puiData )
{
    uint8_t uiMCS;

    // Write slave address and R/W = 1
    HWREG( I2C0_BASE + I2C_O_MSA ) = ( uiSA << 1 ) | 0x01;

    // Initiate I2C transaction
    uiMCS = I2C_MCS_RUN | I2C_MCS_START | I2C_MCS_STOP;
    HWREG( I2C0_BASE + I2C_O_MCS ) = uiMCS;

    // Wait until the controller is no longer busy
    I2C_WaitForControllerReady();

    // Read data from receive register
    *puiData = HWREG( I2C0_BASE + I2C_O_MDR );

    return;
}


void Check_IO_Buttons(void){


    uint8_t uiData;
    PCF8574A_Read(PCF8574A_SA, &uiData);
    if(!(uiData & PCF8574A_SW4))    //SWITCH 4 pushed
    {

        uiData &= ~PCF8574A_LED4;
        if(M_mode && flag){

            SW4_timer++;

          if (SW4_timer  >= 1000){

              g_MCP.fSP += 1;

              }

          if( g_MCP.fSP >=12000){

              g_MCP.fSP = 12000;
          }



        }


    }
    else{


        if(M_mode && SW4_timer > 0 && SW4_timer < 1000)
            {
                g_MCP.fSP += 100;
                if(g_MCP.fSP >= 12000)
                    g_MCP.fSP = 12000;
            }


        SW4_timer = 0;
        flag = 1;
        uiData |= PCF8574A_LED4;

    }

    if(!(uiData & PCF8574A_SW5))   //SWITCH 5
       {

           uiData &= ~PCF8574A_LED5;


       }
       else{


           uiData |= PCF8574A_LED5;
       }

    if(!(uiData & PCF8574A_SW6))    //SWITCH 6
       {

           uiData &= ~PCF8574A_LED6;

           if(M_mode)
               {
                   SW6_timer++;
                   if(SW6_timer >= 1000)
               {

                       g_MCP.fSP -= 1;
                       if(g_MCP.fSP < 0)
                       g_MCP.fSP = 0;



               }
           }


       }
       else{


           uiData |= PCF8574A_LED6;
           if(M_mode && SW6_timer > 0 && SW6_timer < 1000){
               g_MCP.fSP -= 100;
               if(g_MCP.fSP < 0)
               g_MCP.fSP = 0;



           }
           SW6_timer = 0;
       }


    uiData |= PCF8574A_INPUTS;
    PCF8574A_Write(PCF8574A_SA, uiData);


}



//----------------------------------------------------------------------------
// END PCF8574A.C
//----------------------------------------------------------------------------
