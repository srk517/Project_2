//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : LCD.C
// FILE VERSION : 1.0
// PROGRAMMER   : Fateh Ali Shahrukh Khan
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
// 4.0, 2025-11-18, Fateh Ali Shahrukh Khan
//   - Initial release
//
//----------------------------------------------------------------------------
// MODULE DESCRIPTION
//----------------------------------------------------------------------------
//
// LCD Module Driver API.
//
//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------

#include <stdio.h>
#include <lcd.h>
#include "global.h"
#include <systick.h>
#include "mcp7940m.h"
#include "adc.h"
//----------------------------------------------------------------------------
// FUNCTION : LCD_Init( void )
// PURPOSE  : Initializes the LCD module
//----------------------------------------------------------------------------

// float fVREFP = 3.311f;
// float fVREFN = 0.0f;
// char g_sBuffer[ 80 ];



 bool n=1,m=1,o=1,p=1;

 volatile int i;



//float fAIN4;
//float fExtTemp;
//float fIntTemp;

void LCD_Init( void )
{
    // GPIO Port A and E Run Mode Clock Gating Control
    HWREG( SYSCTL_RCGCGPIO ) |= 0x11;

    // Configure Data Bus (initially input)
    HWREG( GPIO_PORTA_BASE + GPIO_O_DEN  ) |= LCD_BUS;
    HWREG( GPIO_PORTA_BASE + GPIO_O_DIR  ) &= ~LCD_BUS;
    HWREG( GPIO_PORTA_BASE + GPIO_O_PDR  ) |= LCD_BUS;
    HWREG( GPIO_PORTA_BASE + GPIO_O_DR4R ) |= LCD_BUS;
    HWREG( GPIO_PORTA_BASE + GPIO_O_DATA + ( LCD_BUS << 2 ) ) = 0;

    // Configure Control Signals
    HWREG( GPIO_PORTE_BASE + GPIO_O_DEN  ) |= LCD_CONTROL;
    HWREG( GPIO_PORTE_BASE + GPIO_O_DIR  ) |= LCD_CONTROL;
    HWREG( GPIO_PORTE_BASE + GPIO_O_DR4R ) |= LCD_CONTROL;
    HWREG( GPIO_PORTE_BASE + GPIO_O_DATA + ( LCD_CONTROL << 2 ) ) = 0;

    // Turn power off to the LCD module
    HWREG( GPIO_PORTE_BASE + GPIO_O_DATA + ( LCD_PWR << 2 ) ) = 0;

    // Delay prior to power-up
    SYSTICK_Delay( 10 );

    // Power-up the LCD module
    HWREG( GPIO_PORTE_BASE + GPIO_O_DATA + ( LCD_PWR << 2 ) ) = LCD_PWR;

    // Delay after power-up
    SYSTICK_Delay( 50 );

    // Set to 4-bit mode
    LCD_WriteNibble( 0, LCD_IC_FUNCTION );
    SYSTICK_Delay( 1 );

    // Configure LCD Module
    LCD_SendInstruction( LCD_IC_FUNCTION | LCD_IC_FUNCTION_2LINE | LCD_IC_FUNCTION_ON );
    LCD_SendInstruction( LCD_IC_DISPLAY | LCD_IC_DISPLAY_ON );
    LCD_SendInstruction( LCD_IC_CLEAR );
    LCD_SendInstruction( LCD_IC_ENTRYMODE | LCD_IC_ENTRYMODE_INC );

    return;
}

//----------------------------------------------------------------------------
// FUNCTION : LCD_SendMessage( char* sMessage )
// PURPOSE  : Writes a zero-terminated string to the LCD module
//----------------------------------------------------------------------------

void LCD_SendMessage( char* sMessage )
{
    // Send entire message at the current cursor position until
    // the NULL character is reached

    while( *sMessage )
    {
        LCD_Write( 1, ( uint8_t )*sMessage++ );
    }

    return;
}

//----------------------------------------------------------------------------
// FUNCTION : LCD_SendInstruction( uint8_t uiInstruction )
// PURPOSE  : Writes one 8-bit instruction to the LCD module
//----------------------------------------------------------------------------

void LCD_SendInstruction( uint8_t uiInstruction )
{
    LCD_Write( 0, uiInstruction );

    return;
}

//----------------------------------------------------------------------------
// FUNCTION : LCD_WaitForReady( void )
// PURPOSE  : Returns only when the LCD module is ready
//----------------------------------------------------------------------------

void LCD_WaitForReady( void )
{
    while( LCD_Read( 0 ) & LCD_IC_STATUS_BUSY );

    return;
}

//----------------------------------------------------------------------------
// FUNCTION : LCD_Write( uint8_t uiRS, uint8_t uiData )
// PURPOSE  : Writes one byte to the LCD module
//----------------------------------------------------------------------------

void LCD_Write( uint8_t uiRS, uint8_t uiData )
{
    LCD_WaitForReady();

    LCD_WriteNibble( uiRS, uiData );
    LCD_WriteNibble( uiRS, uiData << 4 );

    return;
}


void LCD_DEGREE_SYMBOL(uint8_t screen_number){



    LCD_Write( 0, LCD_IC_CGRAMADDR + 0x00 ); // Up-Arrow Character (Accessible as 0x09)
    LCD_Write( 1, 0x06 ); // #...#//diamond degree
    LCD_Write( 1, 0x09 ); // #...#
    LCD_Write( 1, 0x09 ); // #...#
    LCD_Write( 1, 0x06 ); // #...#
    LCD_Write( 1, 0x00 ); // #...#
    LCD_Write( 1, 0x00 ); // #####
    LCD_Write( 1, 0x00 ); // #####
    LCD_Write( 1, 0x00 ); // #...#
    LCD_Write( 0, LCD_IC_DDRAMADDR );
    DEGREE_POS(screen_number);

//    LCD_SendInstruction( LCD_IC_DDRAMADDR + );
//    LCD_SendMessage( "\x08" );

}

void DEGREE_POS(uint8_t number){


    number = number - 1;
    if(number > 15){

        number = (number - 16) +0x40;

    }
    LCD_SendInstruction( LCD_IC_DDRAMADDR + number );
    LCD_SendMessage( "\x08" );
    return;


}

//----------------------------------------------------------------------------
// FUNCTION : LCD_Read( uint8_t uiRS )
// PURPOSE  : Reads one byte from the LCD module
//----------------------------------------------------------------------------

uint8_t LCD_Read( uint8_t uiRS )
{
    uint8_t uiData;

    uiData = LCD_ReadNibble( uiRS );
    uiData |= ( ( LCD_ReadNibble( uiRS ) >> 4 ) & 0x0F );

    return uiData;
}


void LCD_STATIC_DISPLAY(uint8_t state){

    switch (state){

        case CSCRN_EL507:

            LCD_SendInstruction( LCD_IC_CLEAR );
            LCD_SendMessage( "EL 507 : LAB 12" );
            LCD_SendInstruction( LCD_IC_DDRAMADDR + 0x40 );
            LCD_SendMessage( "Embedded Systems" );

            break;
        case CSCRN_TIME:

                   LCD_SendInstruction( LCD_IC_CLEAR );
                   LCD_SendInstruction( LCD_IC_DDRAMADDR + 0x00);
                   LCD_SendMessage( "TIME:" );

                   LCD_SendInstruction( LCD_IC_DDRAMADDR + 0x40);
                   LCD_SendMessage( "DATE:" );
                   break;

        case CSCRN_RPM:

            LCD_SendInstruction( LCD_IC_CLEAR );
            LCD_SendInstruction( LCD_IC_DDRAMADDR + 0x00);
            LCD_SendMessage( "SPEED:       " );
            LCD_SendInstruction( LCD_IC_DDRAMADDR + 0x49);
            LCD_SendMessage( "RPM" );

            break;



        default:
            break;


    }
}



void LCD_DISPLAY(uint8_t state , float RPM) //, bool LCD1, bool LCD2 ){
{

    switch (state){


    case CSCRN_TIME:
        MCP7940M_Read( 0, g_aRTCData, 8 );
           sprintf( g_sBuffer, "%02X:%02X:%02X", g_aRTCData[ 2 ] & 0x1f, g_aRTCData[ 1 ] & 0x7f, g_aRTCData[ 0 ] & 0x7f );
           LCD_SendInstruction( LCD_IC_DDRAMADDR + 0x00 + 6 );
           LCD_SendMessage( g_sBuffer );
           sprintf( g_sBuffer, "20%02X-%02X-%02X", g_aRTCData[ 6 ], g_aRTCData[ 5 ] & 0x1f, g_aRTCData[ 4 ] & 0x3f );
           LCD_SendInstruction( LCD_IC_DDRAMADDR + 0x40 + 6 );
           LCD_SendMessage( g_sBuffer );
           TIME_LCD = 1000;
           break;

    case CSCRN_RPM:

      //  LCD_SendInstruction( LCD_IC_CLEAR );
        sprintf( g_sBuffer, "%6.2f",RPM );
        LCD_SendInstruction( LCD_IC_DDRAMADDR + 0x40);
        LCD_SendMessage( g_sBuffer );
        LCD_1_RPM_DELAY = 250;

        break;


    default:
        break;
    }


}


//----------------------------------------------------------------------------
// END LCD.C
//----------------------------------------------------------------------------
