//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : UART.H
// FILE VERSION : 2.0
// PROGRAMMER   : Fateh Ali Shahrukh Khan
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
// 1.0, 2025-10-24, Fateh Ali Shahrukh Khan
//   - Initial release
//
//----------------------------------------------------------------------------
// MODULE DESCRIPTION
//----------------------------------------------------------------------------
//
// Provides code to support UART0 for a serial communication interface.
//
//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------

#ifndef UART_H_
#define UART_H_

//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------

#include "global.h"

//----------------------------------------------------------------------------
// MACROS
//----------------------------------------------------------------------------

#define UART0_IntEnable()  ( HWREG( NVIC_EN0  ) = ( 1 << 5 ) )
#define UART0_IntDisable() ( HWREG( NVIC_DIS0 ) = ( 1 << 5 ) )

//----------------------------------------------------------------------------
// CONSTANTS
//----------------------------------------------------------------------------

#define UART_CLOCK      80000000
#define UART_BAUDRATE   9600

//----------------------------------------------------------------------------
// FUNCTION PROTOTYPES
//----------------------------------------------------------------------------

void UART_Init( void );

void UART_ReceiveToQueue( void );
void UART_TransmitFromQueue( void );

bool UART_GetChar( uint8_t *puiData );
bool UART_PutChar( uint8_t uiData );

void UART_SendMessage( char* sMessage );
void UART_SendEncodedMessage( char* sMessage, uint8_t uiKey );
int filter_arrow_keys(uint8_t firstChar);
//bool EnterPressed (void);


#endif // UART_H_

//----------------------------------------------------------------------------
// END UART.H
//----------------------------------------------------------------------------
