//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : MAX.C
// FILE VERSION : 1.0
// PROGRAMMER   :  Fateh Ali Shahrukh Khan
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
// 1.0, 2025-11-25,  Fateh Ali Shahrukh Khan
//   - Initial release
//
//----------------------------------------------------------------------------
// MODULE DESCRIPTION
//----------------------------------------------------------------------------
//
// DAC
//
//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------

#include "max.h"
#include "i2c.h"
#include "global.h"

float temp,vout;
void MAX518BCPA_Init()
{

    uint8_t uiData; //0x5C

    uiData = 0x28; // 5c for 1.80 , 38 for 1.10
    MAX518BCPA_Write(MAX_ADDR,uiData);


    return;

}



void MAX_Write_AD1(uint8_t uiSA,uint8_t ControlByte,uint16_t uiData[3],float TEMP_OFFSET,float SubQ)
{
    uint8_t uiMCS;


    // Write Slave Address
    HWREG(I2C0_BASE + I2C_O_MSA ) = (uiSA << 1 );

    // Write Register Address
    HWREG(I2C0_BASE + I2C_O_MDR ) = ControlByte;

    uiMCS = I2C_MCS_RUN | I2C_MCS_START ;

    HWREG(I2C0_BASE + I2C_O_MCS ) = uiMCS;

    I2C_WaitForControllerReady();


 //   uiData[1];
    temp = ( (uiData[1] / 4096.0f) * (VREFP - VREFN) / GAIN ) * 100.0f;
    temp = temp - SubQ + TEMP_OFFSET;
    vout = temp / 10.0f;
    int dac_code = (int)((vout / 4.80f) * 255.0f + 0.5f);


    if (dac_code < 0) dac_code = 0;
    if (dac_code > 255) dac_code = 255;


    // Write Regitser Data
    HWREG(I2C0_BASE + I2C_O_MDR ) = (uint8_t)dac_code;

    uiMCS = I2C_MCS_RUN | I2C_MCS_STOP ;

    HWREG(I2C0_BASE + I2C_O_MCS ) = uiMCS;

    I2C_WaitForControllerReady();

    return;
}

void MAX518BCPA_Write(uint8_t uiSA, uint8_t uiData){

    uint8_t uiMCS;
    HWREG( I2C0_BASE + I2C_O_MSA ) = ( uiSA << 1 );


    HWREG(I2C0_BASE + I2C_O_MDR) = 0x00;
    uiMCS = I2C_MCS_START | I2C_MCS_RUN;
    HWREG(I2C0_BASE + I2C_O_MCS) = uiMCS;
    I2C_WaitForControllerReady();



    HWREG( I2C0_BASE + I2C_O_MDR ) = uiData;
    HWREG( I2C0_BASE + I2C_O_MCS ) = I2C_MCS_RUN | I2C_MCS_STOP;
    I2C_WaitForControllerReady();
    return;

}
