#ifndef DATE_H_
#define DATE_H_


void show_date(void);

void show(time_t t);

#endif
