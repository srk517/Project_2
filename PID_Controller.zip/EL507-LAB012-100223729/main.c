//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : MAIN.C
// FILE VERSION : 11.0
// PROGRAMMER   : Fateh Ali Shahrukh Khan
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
// 11.0, 2025-10-24, Fateh Ali Shahrukh Khan
//   - Initial release
//
//----------------------------------------------------------------------------
// MODULE DESCRIPTION
//----------------------------------------------------------------------------
//
// Main program entry
//
//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------
#define WDT
#include <stdio.h>
#include <string.h>

#include "global.h"
#include "systick.h"
#include "led.h"
#include "sysclk.h"
#include "probe.h"
#include "uart.h"
#include "queue.h"
#include "el507.h"
#include  "upper.h"
#include "Inits.h"
#include "term.h"
#include "contact.h"
#include "date.h"
#include "led.h"
#include "lcd.h"
#include <time.h>
#include "adc.h"
#include "i2c.h"
#include "max.h"
#include "pcf8574a.h"
#include "mcp7940m.h"
#include "motor.h"
#include "qei.h"

//----------------------------------------------------------------------------
// EXTERNAL REFERENCES
//----------------------------------------------------------------------------

extern MOTOR_CONTROL_PARAMS g_MCP;
extern char* QUOTE_Retrieve( void );

CONTACT g_SW3; // PF0
CONTACT g_SW2; // PF4


time_t t;
char date[40];
struct tm *timeinfo;


//uint8_t  g_aRTCData[ 8 ];
uint16_t g_uiRTCCounter;

//char g_sBuffer[ 80 ];

//----------------------------------------------------------------------------
// FUNCTION : Initialize( void )
// PURPOSE  : Initializes the embedded system
//----------------------------------------------------------------------------

void Initialize(void)
{
    GLOBAL_InitSysFlags();
     #ifdef WDT
        WATCH_DOG_INIT();
     #endif
    Init();                          //Causes Reset Switch 1 and Switch 2 Reset
    SYSCLK_Init();

    SYSTICK_Init();                   //
    MOTOR_Init( &g_MCP );            //Motor Init
    //QEI_Init( 0.05f );
    QEI_Init( g_MCP.fdt );
    PROBE_Init();

    LED_Init();                     //LED 1 LED 2 and LED 3

    LCD_Init();


    UART_Init();                   //UART 9600
    TERM_Init(t);                  // Initialize Text On top

    SYSTEM_RESTART_TEXT();        // Cause Text

    LED_TEXT();                   //LED 1 LED 2 LED 3 Text

    message();                    //Static Message Text

    ADC_Init();                   //ADC
    I2C_Init();                   //I2C
    PCF8574A_Init();
    MAX518BCPA_Init();

    g_uiRTCCounter = 1;
    MCP7940M_Init((uint8_t) 10,(uint8_t)9,(uint8_t)3,(uint8_t)10,(uint8_t)12,(uint16_t)2025);  // Set Date and Time  //min,hour,w_day,day,month,year

    return;
}

//----------------------------------------------------------------------------
// FUNCTION : SetMotorSpeed( int )
// PURPOSE  : Print and Set Motor Speed Percentage
//----------------------------------------------------------------------------


static void SetMotorSpeed(int percent){


    if (!M_mode) return;

    if(percent < 0) percent = 0;
    if (percent >100) percent = 100;
    int rpm = (12000 * percent) / 100;
    g_MCP.fSP = (float)rpm;

    Clear_17_14_to_1_30();
    TERM_SetPos(22,19);

    sprintf( g_sBuffer, "Motor speed set to %d%% of maximum (%d RPM)", percent, rpm );

    UART_SendMessage( g_sBuffer );
   // Clear_17_14_to_1_30();

    TERM_RestoreCursor();

}

//----------------------------------------------------------------------------
// FUNCTION : main( void )
// PURPOSE  : Program entry
//----------------------------------------------------------------------------



void main( void )
{

    Initialize();

    FSM fsmHB;
    FSM fsmLED2;
    fsmHB.uiSB = LED_FSM_PAUSE1;
    fsmHB.uiTimer = LED_TIME_PAUSE1;
    fsmHB.count = Reset_Cause_reg();

    fsmLED2.uiSB=LED2_OFF;
    fsmLED2.uiTimer=0;

  //  g_MCP.fSP = 0.0f;
   // uint8_t uiScreen = 1;
    SW4_timer = 0;                       //I2C push buttons    SW4 and SW6 Timer Initialize
    SW6_timer = 0;

    uint8_t uiConvInterval = 1;

    VREFP = 3.311f;                     //Vref and VrefN values set
    VREFN = 0.0f;
    DAC_temp = 0;                       // DAC temperature Bool


    //UART Screen Timer Values set to 1 to avoid UART Clogging
    UART_AMBIENT_TIMER = 1;
    Info_TIMER = 1;
    UART_RPM_TIMER = 1;
    UART_CLOCK_TIMER = 1;
    UART_HELP_TIMER = 1;
    UART_LED3_TIMER = 1;
    UART_MOTOR_TIMER = 1;
    UART_MANUAL_TIMER = 1;
    UART_AUTO_TIMER = 1;
    REFRESH_TIMER = 1;

    //Auto Viper Update for Voltage Value
    AUTOMATIC_TIMER = 100;


    //GAIN Value for OpAMP
    GAIN = 6.30;
    SubQ = -0.008;
    TEMP_OFFSET = -2.7-0.3; // if real - measured > 0 offset + if real - measured < 0 offset -
    ITempOFF=0;


    CLK_COUNT_ = 0;
   // bool led_1=1;
    LED2_FLAG=0;
    LED1_FLAG = 1;
    FIL = 1;
    FIL_2  = 1;
    uint8_t DISPLAY_UNIT=1;
    LCD_STATIC_DISPLAY(DISPLAY_UNIT);
    SECOND_TIMER = 100;

    //BOOL and LCD Delay

    LCD_1 = 0;
    LCD_2 = 0;
    LCD_1_RPM_DELAY = 250;
    TIME_LCD    = 1000;

    TERM_SetPos(1,31); //(17,5) 17,6 17,7
    UART_PutChar(0x5F);
    TERM_SaveCursor();




    CONTACT_Init( &g_SW3, 20, 1 );
    CONTACT_Init( &g_SW2, 20, 1 );

    while( 1 )
    {
    #ifdef WDT
        HWREG(WDT0_BASE + WDT_O_LOAD) = 40000000; //kick watchdog timer
    #endif

        // Sleep using an assembly language instruction
        asm( " wfi" );
//        __wfi(); // ...or we can use a compiler intrinsic instead

        // Check if 1 ms has passed (check the system tick flag)
        if (GLOBAL_CheckSysFlag( SYSFLAGS_SYS_TICK))
        {
            LED_FSM( &fsmHB );
            LED2_FSM(&fsmLED2);

            //Anti UART CLOGGING TIMER DECREMENT
            UART_AMBIENT_TIMER--;
            Info_TIMER--;
            UART_RPM_TIMER--;
            UART_CLOCK_TIMER--;
            UART_HELP_TIMER --;
            UART_LED3_TIMER--;
            UART_MOTOR_TIMER--;
            UART_MANUAL_TIMER--;
            UART_AUTO_TIMER--;
            REFRESH_TIMER--;

            //Time Increment
            t++;
           // Clear the system tick flag
            GLOBAL_ClearSysFlag( SYSFLAGS_SYS_TICK);
            //IO PUSH BUTTONS CHECK
            Check_IO_Buttons();


            //ON SHOT DAC
            if(!DAC_temp){


                MAX_Write_AD1(MAX_ADDR,0x01,ADC_VALUE,TEMP_OFFSET,SubQ); //WRITE TEMP TO DAC


            }

            //GET SPEED REAL TIME
            RPM_speed  = QEI_GetSpeed();


            if( !--uiConvInterval )
                        {
                            // Start a new set of ADC conversions on SS0
                            ADC_SS0_Trigger();

                            uiConvInterval = 250;
                        }


            // LCD DIsplay TIMER FOR TIME AND RPM
            if(DISPLAY_UNIT == 2  && (!--TIME_LCD)) //1000
              {
                 LCD_DISPLAY(DISPLAY_UNIT, 0);//, LCD_1,LCD_2);

              }


            if(DISPLAY_UNIT == 3  && (!-- LCD_1_RPM_DELAY)) //100
                {
                  LCD_DISPLAY(DISPLAY_UNIT, QEI_GetSpeed());//, LCD_1,LCD_2);

                 }


                //AUTOMATIC MODE VALUE UPDATE
            if(A_mode && (!--AUTOMATIC_TIMER) ){

                   Auto_Mode(ADC_VALUE);
                   AUTOMATIC_TIMER = 500;


               }





            //SW2 and SW3 LCD SCREEN CHANGE

            if( CONTACT_Sample( &g_SW3, HWREG(GPIO_PORTF_BASE + GPIO_O_DATA + (0x01 << 2))) )
                        {
                            if( !g_SW3.bOutput )
                            {

                                if(DISPLAY_UNIT > 0 && DISPLAY_UNIT <= 3 ){

                                    //1
                                     DISPLAY_UNIT--;            //0
                               }
                                if(DISPLAY_UNIT == 0){

                                    DISPLAY_UNIT = 3;

                                }
                               // LCD_DISPLAY(DISPLAY_UNIT);
                                LCD_STATIC_DISPLAY(DISPLAY_UNIT);
                                LCD_DISPLAY(DISPLAY_UNIT,  RPM_speed);


                            }
                        }

                        if( CONTACT_Sample( &g_SW2, HWREG(GPIO_PORTF_BASE + GPIO_O_DATA + ( 0x10 << 2))) )
                        {
                            if( !g_SW2.bOutput ){

                                if(DISPLAY_UNIT > 0 && DISPLAY_UNIT <= 3 ){

                                    //LCD_DISPLAY(DISPLAY_UNIT);
                                    DISPLAY_UNIT++;

                                }

                                if(DISPLAY_UNIT > 3){

                                    DISPLAY_UNIT = 1; //page 28

                                }

                                //LCD_DISPLAY(DISPLAY_UNIT);
                                LCD_STATIC_DISPLAY(DISPLAY_UNIT);
                                LCD_DISPLAY(DISPLAY_UNIT,  RPM_speed);


                            }
                        }


                 }

        // Check if a character has been received (check the UART received
        // data flag)


        if( GLOBAL_CheckSysFlag( SYSFLAGS_ADC_SS0 ) )
                {
                    // Clear system ADC SS0 event
                    GLOBAL_ClearSysFlag( SYSFLAGS_ADC_SS0 );


                    uint16_t aValues[ 3 ];
                               if( ADC_SS0_Read( aValues, NUM_ELEMENTS( aValues ) ) == NUM_ELEMENTS( aValues ) )
                               {

                                       while( ADC_SS0_Read( aValues, 1 ) );

                                     //  LCD_DISPLAY(DISPLAY_UNIT,  aValues);
                                       memcpy(ADC_VALUE, aValues, sizeof(aValues));



                               }

                }

        if (GLOBAL_CheckSysFlag( SYSFLAGS_UART_RXD))
        {
            // Clear the UART received data flag
            GLOBAL_ClearSysFlag( SYSFLAGS_UART_RXD);

            // Extract data from the queue and transmit
            uint8_t uiData;


            // FUNCTION TO AVOID ARROW KEY
            //bool s=0;
            while( UART_GetChar( &uiData ) )
            {
               // int tP=0;

                int result = filter_arrow_keys(uiData);
                if(result == -1){

                    continue;

                }

                        //LED 2 TURN ON ON ANY KEY PRESS

                       fsmLED2.uiSB   = LED2_FSM_ON;
                       fsmLED2.uiTimer = PAUSE_LED_2_time;
                       LED2_FLAG = 1;
                       FIL = 1;

                TERM_SaveCursor();

                //CASE 0 to 9 to F for speed update
                switch( ( char )uiData )
                {

                case '0': case '1': case '2': case '3': case '4':
                case '5': case '6': case '7': case '8': case '9':
                case 'F':

                {
                    //If conditions in all most of switch cases to avoid UART CLOG
                    if (UART_MOTOR_TIMER > 2){

                        UART_MOTOR_TIMER = 0;
                    }

                    if(UART_MOTOR_TIMER == 0){

                    int percent = 0;
//                    int percent = (uiData - '0') * 10;
                   if (uiData == 'F'){
                    percent = 100;
                    }
                    else{
                         percent = (uiData - '0') * 10;

                    }

                    if (percent < 0)   percent = 0;
                    if (percent > 100) percent = 100;

                     SetMotorSpeed(percent);
                     UART_MOTOR_TIMER = 2;

                  }
                     break;

                 }

                case 'M':
                    //UART MANUAL CONTROL CASE
                    M_mode = 1;
                    A_mode = 0;
                    if(UART_MANUAL_TIMER > 2){


                        UART_MANUAL_TIMER = 0;

                    }
                    if(UART_MANUAL_TIMER == 0){
                     Clear_17_14_to_1_30();

                     TERM_SetPos(22,19);
                     UART_SendMessage("Mode: Manual Control                                             ");
                     TERM_RestoreCursor();
                     UART_MANUAL_TIMER = 2;
                    }
                    UART_PutChar(0x7f);
                    UART_PutChar(uiData);
                    UART_PutChar(0x5F);

                    break;
                case 'A':
                    //UART AUTO CONTROL CASE
                    M_mode = 0;
                    A_mode = 1;

                    if(UART_AUTO_TIMER > 2){

                        UART_AUTO_TIMER = 0;

                     }
                    if(UART_AUTO_TIMER == 0){

                        Clear_17_14_to_1_30();
                        TERM_SetPos(22,19);
                        UART_SendMessage("Mode: Automatic Control                                          ");
                       TERM_RestoreCursor();
                       UART_AUTO_TIMER = 2;
                  }

                    UART_PutChar(0x7f);
                    UART_PutChar(uiData);
                    UART_PutChar(0x5F);

                    break;
                    //UART RPM CASE
                case 'R':

                    if (UART_RPM_TIMER > 2) {
                            UART_RPM_TIMER = 0;
                        }
                    if(UART_RPM_TIMER == 0){
                    Clear_17_14_to_1_30();
                    RPM_STATIC();
                    RPM_DYNAMIC(RPM_speed);
                    UART_RPM_TIMER = 2;
                  }
                    UART_PutChar(0x7f);
                    UART_PutChar(uiData);
                    UART_PutChar(0x5F);
                 break;
                 //UART TEMP CASE
                case 'T':

                    if(UART_AMBIENT_TIMER > 2){


                      UART_AMBIENT_TIMER = 0;

                    }

                    if (UART_AMBIENT_TIMER == 0){

                        Clear_17_14_to_1_30();
                        TERM_SetPos(1,19);
                        CMSG_ATEMP();
                        TERM_SetPos(22,19);
                        AMBI_DIS_UART(ADC_VALUE);
                        TERM_SetPos(1,20);
                        CMSG_ITEMP();
                        TERM_SetPos(23,20);
                        ITemp_Dis_UART(ADC_VALUE);
                        TERM_RestoreCursor();
                        UART_AMBIENT_TIMER = 2;
                        DAC_temp = 1;
                    }

                    UART_PutChar(0x7f);
                    UART_PutChar(uiData);
                    UART_PutChar(0x5F);

                    break;


                 //UART REFRESH FUNCTION PREVIOUSLY IT WAS 0
                case 'J':
                    if(REFRESH_TIMER > 2){

                        REFRESH_TIMER = 0;

                    }

                    if(REFRESH_TIMER == 0){

                        UART_SendMessage("\e[?25l");
                        //time_t tt;
                        TERM_Init(t);
                        SYSTEM_RESTART_TEXT();
                        LED_TEXT();
                        Keep_MSG();
                        message();
                        TERM_SetPos(1,31);
                        UART_PutChar(0x5F);
                        REFRESH_TIMER = 2;
                      }


                    break;

                case 'I':

                    //UART INFO CASE
                    if (Info_TIMER > 2) {
                        Info_TIMER= 0;
                       }
                    if(Info_TIMER== 0){
                     Clear_17_14_to_1_30();
                     TERM_SetPos(1,19);
                     UART_SendMessage("EL507 Embedded Control Systems II");
                     UART_SendMessage("\r\n");
                     UART_SendMessage("Embedded Systems v1.0");
                     UART_SendMessage("\r\n");
                     TIME_AND_DISPLAY();
                     Info_TIMER = 2;
                    }
                    UART_PutChar(0x7f);
                    UART_PutChar(uiData);
                    UART_PutChar(0x5F);


                     break;
                case 'C':
                    //UART CLOCK CASE
                    if (UART_CLOCK_TIMER > 2) {
                       UART_CLOCK_TIMER = 0;
                     }


                      if (UART_CLOCK_TIMER == 0){
                           Clear_17_14_to_1_30();
                           TERM_SetPos(1,19);
                           CLOCK();
                           TERM_RestoreCursor();
                           UART_CLOCK_TIMER = 2;
                         }
                      UART_PutChar(0x7f);
                      UART_PutChar(uiData);
                      UART_PutChar(0x5F);
                        break;


                case '?':
                    //UART HELP CASE
                    if (UART_HELP_TIMER > 2) {
                           UART_HELP_TIMER = 0;
                       }


                    if (UART_HELP_TIMER == 0) {
                            Clear_17_14_to_1_30();
                            HELP();
                            UART_HELP_TIMER = 2;

                    }
                    UART_PutChar(0x7f);
                    UART_PutChar(uiData);
                    UART_PutChar(0x5F);

                    break;


                case 'L':
                    //UART LED 3 CASE
                    if (UART_LED3_TIMER > 2){

                        UART_LED3_TIMER = 0;

                    }
                        if (UART_LED3_TIMER == 0){
                        Clear_17_14_to_1_30();
                        HWREG(GPIO_PORTF_BASE + GPIO_O_DATA + (0x0E << 2)) ^= 0x08;
                        LED3_CHECK();
                        UART_LED3_TIMER = 2;

                    }
                    UART_PutChar(0x7f);
                    UART_PutChar(uiData);
                    UART_PutChar(0x5F);
                    break;
                case 0x12:       //CNTRL+R
                    //LED_LED3(1);
                    HWREG(APINT) = 0x05FA0004;
                    break;
                case 0x17:          //CNTRL+W
                    #ifdef WDT
                    while(1){}
                #endif


                    //break;

                case 0x0D:

                    TERM_RestoreCursor();
                    UART_PutChar(0x7f);
                    UART_PutChar(0x0D);
                    UART_PutChar(0x0A);
                    UART_PutChar(0x5F);
                    break;

                case 0x7f:
                    UART_PutChar('\b');
                    UART_PutChar(' ');
                    UART_PutChar('\b');
                    break;
                default:
                 UART_PutChar(0x7f);
                 UART_PutChar(uiData);
                 UART_PutChar(0x5F);
                 TERM_SaveCursor();
                // tP = 0;


                }
                TERM_SaveCursor();
               // EL507_ToUpper( (char*) &uiData );
            }
        }
    }
}

//----------------------------------------------------------------------------
// END MAIN.C
//----------------------------------------------------------------------------
