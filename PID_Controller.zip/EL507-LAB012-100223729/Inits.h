//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : INITS.H
// FILE VERSION : 2.0
// PROGRAMMER   : Fateh Ali Shahrukh Khan
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
// 1.0, 2025-10-14, Fateh Ali Shahrukh Khan
//   - Initial release
//
//----------------------------------------------------------------------------
// MODULE DESCRIPTION
//----------------------------------------------------------------------------
//
// My Inits header file
//
//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------
/*
 * Inits.h
 *
 *  Created on: Oct 7, 2025
 *      Author: fkhan6
 */

#ifndef INITS_H_
#define INITS_H_

#include "global.h"

void Brown_Out(void);
uint16_t Reset_Cause_reg(void);
void SW3_Init(void);
void SW2_Init(void);
void WATCH_DOG_INIT(void);
void Init( void );
void Keep_MSG(void);

#endif /* INITS_H_ */
