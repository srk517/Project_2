#include <time.h>
#include "uart.h"
#include <stdio.h>
#include "date.h"
#include <string.h>

//char copyBuffer[40];
//char Buffer[40];
//struct tm *t2;
struct tm *timeinfo;
//time_t t;
void show_date(void){



    //struct tm *timeinfo;


   // strftime(Buffer, sizeof(Buffer), "\x1b[36m""TODAY IS : %a %b %d %Y\r\n""\x1b[0m\r\n", timeinfo);
    //strcpy(copyBuffer, Buffer);
   // sprintf( Buffer, "%s", asctime(timeinfo) );
   // TERM_SetPos(1,1);
    //UART_SendMessage( Buffer );
    //TERM_RestoreCursor();
    //show(Buffer);

}

void show (time_t t){
    time(&t);
    timeinfo = localtime(&t);
   // strftime(g_sBuffer, sizeof(g_sBuffer), "\x1b[36m""TODAY IS : %a %b %d %Y\r\n""\x1b[0m\r\n", timeinfo);
    UART_SendMessage(  "\x1b[36m""TODAY IS : Embedded Day\r\n""\x1b[0m\r\n" );
    //UART_SendMessage( g_sBuffer );
}
