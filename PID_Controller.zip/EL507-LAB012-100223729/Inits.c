//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : INITS.C
// FILE VERSION : 2.0
// PROGRAMMER   : Fateh Ali Shahrukh Khan
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
// 1.0, 2025-10-24, Fateh Ali Shahrukh Khan
//   - Initial release
//
//----------------------------------------------------------------------------
// MODULE DESCRIPTION
//----------------------------------------------------------------------------
//
// My Inits dot C
//
//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------
#include "Inits.h"
#include "led.h"
#include "term.h"
#include <string.h>
#pragma NOINIT(cause)
uint32_t cause;

void Brown_Out(void){

    HWREG(PBORCTL) |= 0x06;

}

void WATCH_DOG_INIT(void){


    HWREG(SYSCTL_RCGCWD) |= (1 << 0);
    while ((HWREG(SYSCTL_PRWD) & (1 << 0)) == 0){

    }
    HWREG(WDT0_BASE + WDT_O_LOCK) = 0x1ACCE551;
    HWREG(WDT0_BASE + WDT_O_LOAD) = 16000000;
    HWREG(WDT0_BASE + WDT_O_CTL) = (1<<0)|(1 << 1);

}

void SW3_Init(void){

       HWREG( SYSCTL_RCGCGPIO ) |= 0x20;
       HWREG (GPIO_PORTF_BASE + GPIO_O_LOCK) = 0x4C4F434B;
       HWREG (GPIO_PORTF_BASE + GPIO_O_CR)   = 0x01;

       HWREG (GPIO_PORTF_BASE + GPIO_O_DIR ) |= 0x00;  //pf1,pf2,pf3 pf4 = sw1,pf0 sw2
       HWREG (GPIO_PORTF_BASE + GPIO_O_DEN ) |= 0x01;
      // HWREG (GPIO_PORTF_BASE + GPIO_O_DATA + (0x01 << 2) )  = 0x00;
       HWREG (GPIO_PORTF_BASE + GPIO_O_PUR) |= 0x01; //sw1 = pf4,sw2 = pf0


}
void SW2_Init(void){

          HWREG (GPIO_PORTF_BASE + GPIO_O_DIR ) |= 0x00;
          HWREG (GPIO_PORTF_BASE + GPIO_O_DEN ) |= 0x10;
          //HWREG (GPIO_PORTF_BASE + GPIO_O_DATA + (0x10 << 2) )  = 0x00;
          HWREG (GPIO_PORTF_BASE + GPIO_O_PUR) |= 0x10;
}


uint16_t Reset_Cause_reg(void){

    uint32_t count;


    if(HWREG( REG_O_RESC ) & 0x0000003F){


            cause = HWREG( REG_O_RESC );

       }

      HWREG( REG_O_RESC ) = ~0x0001003F;



     if(cause & (1 << 2)){  //Brown-Out Reset

             //FLASH_COUNT(4);
        TERM_SetPos(19,12);
        UART_SendMessage("BROWN-OUT RESET\r\n");
        strcpy(KEEP_MSG,"BROWN-OUT RESET\r\n" );
            count = 4;

        }

    else if(cause & (1 << 1)){  //Power-On Reset

              //FLASH_COUNT(3);
             count = 3;
             TERM_SetPos(19,12);
             UART_SendMessage("POWER-ON RESET\r\n");
             strcpy(KEEP_MSG,"POWER-ON RESET\r\n" );


          }

    else if(cause & (1 << 0)){        //External Reset Sw1

                //FLASH_COUNT(2);
                count = 2;
                TERM_SetPos(19,12);
              //  SHOW_MSG = "EXTERNAL RESET\r\n";
                UART_SendMessage("EXTERNAL RESET\r\n");
                strcpy(KEEP_MSG,"EXTERNAL RESET\r\n" );

            }

     else if(cause & (1<<3)){  //Watchdog Timer (WDT0) Reset (Initiated by SW2)

             //FLASH_COUNT(5);
             TERM_SetPos(19,12);
             UART_SendMessage("WATCH-DOG-TIMER RESET\r\n");
             strcpy(KEEP_MSG,"WATCH-DOG-TIMER RESET\r\n" );
             count = 5;

         }

     else if(cause & (1 << 4)){ //Software Reset (Initiated by SW3)

             // FLASH_COUNT(6);
         TERM_SetPos(19,12);
         UART_SendMessage("SOFTWARE RESET\r\n");
         strcpy(KEEP_MSG,"SOFTWARE RESET\r\n" );
             count = 6;

         }

     else if(cause & (1<<16)){

                   //FLASH_COUNT(7);
                 TERM_SetPos(19,12);
                 UART_SendMessage("MAIN OSCILLATOR FAILURE RESET\r\n");
                 strcpy(KEEP_MSG,"MAIN OSCILLATOR FAILURE RESET\r\n" );
                 count = 7;

               }

    return count;
}


void Keep_MSG(){

    TERM_SetPos(19,12);
    UART_SendMessage(KEEP_MSG);

}



void Init( void )
{

    //Reset_Cause_reg();
    Brown_Out();

    SW3_Init();
    SW2_Init();

    return;
}
