//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : LED.H
// FILE VERSION : 1.0
// PROGRAMMER   : Fateh Ali Shahrukh Khan
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
//1.0, 2025-10-14, Fateh Ali Shahrukh Khan
//   - Initial release
//
//----------------------------------------------------------------------------
// INCLUSION LOCK
//----------------------------------------------------------------------------

#ifndef LED_H_
#define LED_H_

//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------

#include "global.h"
//void FLASH_COUNT(uint16_t c);
//----------------------------------------------------------------------------
// CONSTANTS
//----------------------------------------------------------------------------

#define LED_TIME_HBON    250 // Heartbeat On-Time
#define LED_TIME_HBOFF   750 // Heartbeat Off-Time

#define FAST_PULSEON   125
#define FAST_PULSEOFF  375

#define LED_TIME_PAUSE1 1972-65-6
#define LED_TIME_PAUSE2 2375

#define PAUSE_LED_2_time 500

enum LED_FSM_STATES
{
    LED_FSM_RESET = 0, //S
    LED_FSM_PAUSE1,   //1
    LED_FSM_FAST_ON,
    LED_FSM_FAST_OFF,
    LED_FSM_PAUSE2,
    LED_FSM_HBON,     //2
    LED_FSM_HBOFF,    //3
   // PAUSE_LED_2,
};

enum LED2_FSM_STATES
{

    LED2_FSM_ON = 0,
    LED2_OFF,

};


typedef struct
{
    uint8_t  uiSB;
    uint16_t uiTimer;
    uint16_t count;
    //bool    bReset;

} FSM;


//----------------------------------------------------------------------------
// FUNCTION PROTOTYPES
//----------------------------------------------------------------------------

void LED_Init( void );
void LED_LED1( bool bOn );
void LED_LED2( bool bOn );
void LED_LED3( bool bOn);
void LED_FSM( FSM* pFSM );
void LED2_FSM(FSM* pFSM);
void LED3_CHECK(void);
void LED2_TURNOFF(void);

#endif // LED_H_

//----------------------------------------------------------------------------
// END LED.H
//----------------------------------------------------------------------------
