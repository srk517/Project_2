//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : LED.C
// FILE VERSION : 5.0
// PROGRAMMER   : Fateh Ali Shahrukh Khan
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
// 1.0, 2025-10-24, Fateh Ali Shahrukh Khan
//   - Initial release
//
//----------------------------------------------------------------------------
// MODULE DESCRIPTION
//----------------------------------------------------------------------------
//
// Controls the LED and LED sequencer using a software encoded state machine.
//
//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------

#include "led.h"
#include "term.h"
#include "pcf8574a.h"
//static uint16_t count = 2;
//----------------------------------------------------------------------------
// EXTERNAL REFERENCES
//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
// FUNCTION : LED_Init( void )
// PURPOSE  : Initializes the GPIO pin to control the LED
//----------------------------------------------------------------------------

void LED_Init( void )
{
    // Enable GPIO Port F
    HWREG(SYSCTL_RCGCGPIO) |= 0x20;

    // Configure PF1 as an output
    HWREG(GPIO_PORTF_BASE + GPIO_O_DEN) |= 0x0E;
    HWREG(GPIO_PORTF_BASE + GPIO_O_DIR) |= 0x0E;
    HWREG(GPIO_PORTF_BASE + GPIO_O_DATA + (0x0E << 2)) = 0x00;

    return;
}




//void FLASH_COUNT(uint16_t c )
//{
//
//    count = c;
//
//}

//----------------------------------------------------------------------------
// FUNCTION : LED_LED1( bool bOn )
// PURPOSE  : Controls the state of the LED
//----------------------------------------------------------------------------


void LED_LED2( bool bOn)
{

    HWREG(GPIO_PORTF_BASE + GPIO_O_DATA + (0x04 << 2)) = bOn ? 0x04 : 0;
        if(FIL > 0){
           // UART_SendMessage("\x0E");
              UART_SendMessage("\e[?25l");
              TERM_SetPos(17,15);
              //UART_SendMessage("\e(0 `\e(B");
            //UART_SendMessage("\x0F");
              UART_SendMessage("\x1B[31m\x1B(0`\x1B(B");
              TERM_RestoreCursor();
              FIL--;
             }

      return;
}


void LED2_TURNOFF(void){

    HWREG(GPIO_PORTF_BASE + GPIO_O_DATA + (0x04 << 2)) = 0x00;

    if(LED2_FLAG){
       // UART_SendMessage("\x0E");
        UART_SendMessage("\e[?25l");
        TERM_SetPos(17,15);
        UART_SendMessage("\x1B[0m\x1B(B ");
        //UART_SendMessage("\x0F");
        TERM_RestoreCursor();
        LED2_FLAG = 0;
    }
}

void LED2_FSM(FSM* pFSM){


    switch( pFSM->uiSB )
    {

        case LED2_FSM_ON:


                LED_LED2( 1 );


            if( !--pFSM->uiTimer )
            {
                pFSM->uiSB   = LED2_OFF; //next case running 2
                pFSM->uiTimer = 0; //time for the case 125ms
                }


            break;
        case LED2_OFF:
            //LED_LED2(0);
            LED2_TURNOFF();
            break;
        default:
            //LED_LED2(0);
            break;

    }
    return;

}

void LED3_CHECK(void){


    if(HWREG(GPIO_PORTF_BASE + GPIO_O_DATA + (0x08 << 2))){
                UART_SendMessage("\e[?25l");
                TERM_SetPos(17,16);
                //UART_SendMessage("\e(0 `\e(B");
                UART_SendMessage("\x1B[31m\x1B(0`\x1B(B \x1B[0m");
                //UART_SendMessage("\x0F");
                TERM_SetPos(5,19);
                UART_SendMessage("LED3:  ON                                                     \r\n");
                TERM_RestoreCursor();

            }
            else {
                UART_SendMessage("\e[?25l");
                TERM_SetPos(17,16);
                UART_SendMessage("\x1B[0m\x1B(B ");
                TERM_SetPos(5,19);

                UART_SendMessage("LED3:  OFF                                                     \r\n");
                TERM_RestoreCursor();
                //UART_SendMessage(" ");
                //UART_SendMessage("\x0F");
            }
    TERM_RestoreCursor();
    return;


}

void LED_LED3( bool bOn)
{
    HWREG(GPIO_PORTF_BASE + GPIO_O_DATA + (0x08 << 2)) = bOn ? 0x08 : 0;


//        uint8_t uiData;
//        PCF8574A_Read( PCF8574A_SA, &uiData );
//        uiData = bOn ? uiData & ~PCF8574A_LED5 : uiData | PCF8574A_LED5;
//        uiData |= PCF8574A_INPUTS;
//        PCF8574A_Write( PCF8574A_SA, uiData );

    LED3_CHECK();


    return;
}

//----------------------------------------------------------------------------
// FUNCTION : LED_FSM( bool bReset )
// PURPOSE  : LED Finite State Machine control
//----------------------------------------------------------------------------

// Note that this function does not use a static variable to keep track of
// the FSM state or timing. Much like the QUEUE, a structure is used to hold
// this information and a pointer is passed to the function.

void LED_LED1( bool bOn)
{
    HWREG(GPIO_PORTF_BASE + GPIO_O_DATA + (0x02 << 2)) = bOn ? 0x02 : 0;


//    uint8_t uiData;
//
//    PCF8574A_Read( PCF8574A_SA, &uiData );
//    uiData = bOn ? uiData & ~PCF8574A_LED4 : uiData | PCF8574A_LED4;
//    uiData |= PCF8574A_INPUTS;
//    PCF8574A_Write( PCF8574A_SA, uiData );



    if(HWREG(GPIO_PORTF_BASE + GPIO_O_DATA + (0x02 << 2))){
       if(FIL_2){
         UART_SendMessage("\e[?25l");
         TERM_SetPos(17,14);
         //UART_SendMessage("\e(0 `\e(B");
         UART_SendMessage("\x1B[31m\x1B(0`\x1B(B");
         TERM_RestoreCursor();
         FIL_2 --;
    }

       return;
    }
}

void LED1_TURNOFF(void){

    HWREG(GPIO_PORTF_BASE + GPIO_O_DATA + (0x02 << 2)) = 0;


//    uint8_t uiData;
//
//    PCF8574A_Read( PCF8574A_SA, &uiData );
//    uiData = uiData | PCF8574A_LED4;
//    uiData |= PCF8574A_INPUTS;
//    PCF8574A_Write( PCF8574A_SA, uiData );



    if(LED1_FLAG){

        UART_SendMessage("\e[?25l");
        TERM_SetPos(17,14);
        //UART_SendMessage(" ");
        UART_SendMessage("\x1B[0m\x1B(B ");

        LED1_FLAG = 0;
        TERM_RestoreCursor();
        //FIL_2 = 2;
    }

}




void LED_FSM( FSM* pFSM )
{

//    if(pFSM->bReset){
//
//
//        pFSM->uiSB = LED_FSM_RESET;
//
//    }

    switch( pFSM->uiSB )
    {


//    case LED_FSM_RESET:
//        LED_LED1( 0 );
//        pFSM->uiSB =  LED_FSM_PAUSE1;
//        pFSM->uiTimer = LED_TIME_PAUSE1;


    case LED_FSM_PAUSE1:

        //LED_LED1( 0 );
        LED1_TURNOFF();

        if( !--pFSM->uiTimer )
        {
            pFSM->uiSB   = LED_FSM_FAST_ON; //next case running 2
            pFSM->uiTimer = FAST_PULSEON; //time for the case 125ms
           // LED1_FLAG = 1;    //true bool

        }

        break;

    case LED_FSM_FAST_ON:

            LED_LED1( 1 );

            if( !--pFSM->uiTimer )
            {
                pFSM->uiSB    = LED_FSM_FAST_OFF;
                pFSM->uiTimer = FAST_PULSEOFF;
                LED1_FLAG = 1;        //off bool
            }

        break;
    case LED_FSM_FAST_OFF:

            //LED_LED1( 0 );
            LED1_TURNOFF();

            if( pFSM->count ){ //3 //2//1

                if( !--pFSM->uiTimer )
                        {
                            pFSM->uiSB    = LED_FSM_FAST_ON;
                            pFSM->uiTimer = FAST_PULSEON;
                            pFSM->count--; //2,1
                            FIL_2 =1;
                            //LED1_FLAG = 1;  //bool on
                        }

            }

            else
            {
                pFSM->uiSB    = LED_FSM_PAUSE2;
                pFSM->uiTimer = LED_TIME_PAUSE2;
                LED1_FLAG = 1;    //bool off
            }
            break;

    case LED_FSM_PAUSE2:

               //LED_LED1( 0 );
               LED1_TURNOFF();

               if(  !--pFSM->uiTimer )
               {
                   pFSM->uiSB    = LED_FSM_HBON;
                   pFSM->uiTimer = LED_TIME_HBON;
                   FIL_2 =1;
                   //LED1_FLAG = 1;    //bool on
               }

               break;
    case LED_FSM_HBON:
        LED_LED1( 1 );
        if( !--pFSM->uiTimer )
        {
            pFSM->uiSB = LED_FSM_HBOFF;
            pFSM->uiTimer = LED_TIME_HBOFF;
            LED1_FLAG = 1;    //bool off
        }
        break;
    case LED_FSM_HBOFF:
        //LED_LED1( 0 );
        LED1_TURNOFF();
        if( !--pFSM->uiTimer )
        {
            pFSM->uiSB = LED_FSM_HBON;
            pFSM->uiTimer = LED_TIME_HBON;
            FIL_2 =1;    //bool on
        }

        break;
    default: // Unknown State
       // LED_LED1( 0 );
        LED1_TURNOFF();
        //
        //pFSM->uiSB = LED_FSM_RESET;
        //pFSM->uiTimer = LED_TIME_HBON;
        break;
    }

    return;
}





//----------------------------------------------------------------------------
// END LED.C
//----------------------------------------------------------------------------
