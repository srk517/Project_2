/*
 * upper.h
 *
 *  Created on: Oct 12, 2025
 *      Author: fkhan6
 */

#ifndef UPPER_H_
#define UPPER_H_


#include <stdint.h>
#include <stdbool.h>

// Function to convert lower-case characters to upper-case
bool EL507_ToUpper( char *pcData );



#endif /* UPPER_H_ */
