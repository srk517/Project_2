//----------------------------------------------------------------------------
// COMPANY      : Confederation College
// FILE         : CONTACT.C
// FILE VERSION : 1.0
// PROGRAMMER   : Programmer Name
//----------------------------------------------------------------------------
// REVISION HISTORY
//----------------------------------------------------------------------------
//
// 1.0, YYYY-MM-DD, Programmer Name
//   - Initial release
//
//----------------------------------------------------------------------------
// MODULE DESCRIPTION
//----------------------------------------------------------------------------
//
// Code to support electro-mechanical contact inputs.
//
//----------------------------------------------------------------------------
// INCLUDE FILES
//----------------------------------------------------------------------------

#include "contact.h"
#include "term.h"
#include <stdio.h>
//----------------------------------------------------------------------------
// EXTERNAL REFERENCES
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// FUNCTION : CONTACT_Init( CONTACT *pContact, uint32_t uiReload, bool bInitialState )
// PURPOSE  : Initializes the contact interface
//----------------------------------------------------------------------------

void CONTACT_Init( CONTACT *pContact, uint32_t uiReload, bool bInitialState )
{
    pContact->bCurrInput = bInitialState;
    pContact->bPrevInput = bInitialState;

    pContact->uiCounter = 0;
    pContact->uiReload  = uiReload;

    pContact->bEvent  = 0;
    pContact->bOutput = bInitialState;

    pContact->bReserved = 0;

    return;
}

//----------------------------------------------------------------------------
// FUNCTION : CONTACT_Sample( CONTACT *pContact, bool bInput )
// PURPOSE  : Samples the specified contact input
//----------------------------------------------------------------------------

bool CONTACT_Sample( CONTACT *pContact, bool bInput )
{
    pContact->bCurrInput = bInput;

    if( pContact->bCurrInput ^ pContact->bPrevInput )
    {
        // Change detected from previous sample - reload counter
        pContact->uiCounter = pContact->uiReload;
    }
    else
    {
        // No change from previous sample
        if( pContact->uiCounter )
        {
            pContact->uiCounter--;
        }
    }
    // Prepare for next sample
    pContact->bPrevInput = pContact->bCurrInput;

    // Update the event and output
    pContact->bEvent  = pContact->uiCounter == 1;
    pContact->bOutput = pContact->bEvent ? pContact->bCurrInput : pContact->bOutput;

    return pContact->bEvent;
}

void UpdateTransitionCount( int32_t iTC )
{
    // String buffer for message
   // char sBuffer[32];

    TERM_SaveCursor();
    TERM_HideCursor();
    {
        TERM_SetPos( 6 , 23 );// TERM_SetPos(9,9);
        sprintf( g_sBuffer, "%+4d", iTC );
        UART_SendMessage( g_sBuffer );
    }
    TERM_RestoreCursor();
  //  TERM_ShowCursor();

    return;
}

void Initial_display(void)
{

       //char sBuffer[32];

       TERM_SetPos( 6 , 23 );// TERM_SetPos(9,9);
       sprintf( g_sBuffer, "%4d", 0 );
       UART_SendMessage( g_sBuffer );

}


//----------------------------------------------------------------------------
// END CONTACT.C
//----------------------------------------------------------------------------
